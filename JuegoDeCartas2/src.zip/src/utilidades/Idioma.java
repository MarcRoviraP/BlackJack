package utilidades;

public class Idioma {

}
