package enumerados;

public enum Ganar {

	ganado,
	perdido,
	empate;
}
