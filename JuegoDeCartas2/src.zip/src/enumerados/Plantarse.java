package enumerados;

public enum Plantarse {

	seguir,
	parar;
}
