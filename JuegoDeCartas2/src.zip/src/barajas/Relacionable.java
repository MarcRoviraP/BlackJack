package barajas;

public interface Relacionable {

	public void esMayorQue(Jugador Crupier , Jugador jugador);
	public void esMenorQue(Jugador Crupier , Jugador jugador);
	public void esIgualQue(Jugador Crupier , Jugador jugador);
}
